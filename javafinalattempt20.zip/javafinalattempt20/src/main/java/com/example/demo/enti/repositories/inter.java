package com.example.demo.enti.repositories;

import com.example.demo.enti.post;
import org.springframework.data.repository.CrudRepository;

public interface inter extends CrudRepository<post, Long> {
}
