package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Javafinalattempt19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
